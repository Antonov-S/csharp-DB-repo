﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString 
            => @"Server=T450\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
