﻿namespace MusicHub.Data
{
   public static class Configuration
    {
        public static string ConnectionString =
            @"Server=T450\SQLEXPRESS;Database=MusicHub;Trusted_Connection=True";
    }
}
