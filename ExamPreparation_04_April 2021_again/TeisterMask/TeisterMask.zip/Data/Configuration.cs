﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=T450\SQLEXPRESS;Database=TeisterMask;Trusted_Connection=True";
    }
}
