﻿namespace CarDealer.DTO
{
    public class SuppliersInputObject
    {
        public string Name { get; set; }

        public bool IsImporter { get; set; }
    }
}
