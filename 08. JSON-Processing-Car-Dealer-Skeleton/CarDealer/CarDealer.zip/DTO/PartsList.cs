﻿namespace CarDealer.DTO.CarsListOfPartsDto
{
    public class PartsList
    {
        public string Name { get; set; }

        public string Price { get; set; }
    }
}