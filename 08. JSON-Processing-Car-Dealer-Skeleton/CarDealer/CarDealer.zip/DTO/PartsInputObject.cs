﻿namespace CarDealer.DTO
{
    public class PartsInputObject
    {
        public string Name { get; set; }

        public decimal Price { get; set; }

        public int Quantity { get; set; }

        public int supplierId { get; set; }


    }

    //"name": "Bonnet/hood",
    //"price": 1001.34,
    //"quantity": 10,
    //"supplierId": 17
}
