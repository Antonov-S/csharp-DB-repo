﻿using System;

namespace CarDealer.DTO
{
    public class CustoerInputObject
    {
        public string Name { get; set; }

        public DateTime birthDate { get; set; }

        public bool IsYoungDriver { get; set; }

    }

    //"name": "Emmitt Benally",
    //"birthDate": "1993-11-20T00:00:00",
    //"isYoungDriver": true
}
